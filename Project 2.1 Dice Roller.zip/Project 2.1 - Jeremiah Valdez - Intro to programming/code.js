var rollCount = 0;
var continueRolling = true;
var outputElement = document.getElementById("output");
var rollButton = document.getElementById("rollButton");

function rollDice() {
    if (continueRolling) {
        rollCount++;

        if (rollCount % 9 === 0) {
            outputElement.textContent += "You rolled a 999!\n";
        } else {
            var result = Math.floor(Math.random() * 1000) + 1;
            outputElement.textContent += "You rolled a " + result + "!\n";
        }
    }
}

document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        rollDice();
    } else if (event.key.toLowerCase() === "q") {
        continueRolling = false;
        outputElement.textContent += "Exiting the program. Thanks for playing!\n";
        rollButton.disabled = true; // Disable the button when quitting
    }
});

rollButton.addEventListener("click", rollDice);